#!/bin/bash

python main.py --logic casualbot --email=test@email.com --name=ardi --password=222222 --team etimot &
python main.py --logic botgaklogis --email=test1@email.com --name=maskiel --password=111111 --team etimob &
python main.py --logic gacorbot --email=test2@email.com --name=cipa --password=333333 --team etimom &
python main.py --logic superbot --email=test3@email.com --name=gelo --password=444444 --team etimoc &